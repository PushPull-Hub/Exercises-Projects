// Write a JavaScript program that:
// - Asks the user for the height in meters
// - Asks the user for the weight in kilograms
// - Calculates the Body Mass Index as BMI = kg/m^2
// - If the BMI is in the range [0 - 18.4], print the value and "underweight"
// - If the BMI is in the range [18.5 - 24.9], print the value and "normal"
// - If the BMI is in the range [25 - ], print the value and "overweight"

let name = prompt('hee user can you insert your name ?');
let height = prompt(
  `ok ${name} can you insert your height in the unit meter please ?`,
);
let weight = prompt(
  'ok can you Insert your weight in the unit Kilograms please ?',
);

function BodyMassIndex(height, weight) {
  let BMI = 0;
  if (typeof height == 'number' && typeof weight == 'number') {
    BMI = height / weight;
    return BMI;
  }
  return BMI * 2;
}

if (BMI <= 18.4) {
  alert(`ok ${name} ${BMI} is underweight `);
} else if (BMI > 18.5 && BMI < 24.9) {
  alert(`ok ${name} ${BMI} is Normal`);
} else if (BMI > 25) {
  alert(`ok ${name} ${BMI} is overweight`);
}

console.log(BodyMassIndex(80, 1.5));
